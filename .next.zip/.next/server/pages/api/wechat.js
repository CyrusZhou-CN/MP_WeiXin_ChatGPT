"use strict";
(() => {
var exports = {};
exports.id = 764;
exports.ids = [764];
exports.modules = {

/***/ 648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 684:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ getAccessToken)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(648);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sysconfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fileUrl = "./access_token.json";
const readAccessToken = ()=>{
    try {
        const accessTokenStr = fs__WEBPACK_IMPORTED_MODULE_1___default().readFileSync(fileUrl, "utf8");
        const accessToken = JSON.parse(accessTokenStr);
        const expireTime = new Date(accessToken.expireTime).getTime();
        const currentTime = new Date().getTime();
        if (accessToken.token && expireTime > currentTime) {
            console.log("get access_token from local file", accessToken.token);
            return accessToken.token;
        }
        console.log("access_token expired");
        return undefined;
    } catch (e) {
        console.log("read access_token error:", e.message);
        return undefined;
    }
};
const writeAccessToken = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].appID */ .Z.appID}&secret=${_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].appSecret */ .Z.appSecret}`);
    if (!res.data.access_token || !res.data.expires_in) {
        console.error("ACCESS_TOKEN为空", res.data);
        throw new Error("access_token为空");
    }
    const now = new Date();
    const expireTime = now.getTime() + res.data.expires_in * 1000;
    const accessToken = {
        token: res.data.access_token,
        expireTime: expireTime
    };
    fs__WEBPACK_IMPORTED_MODULE_1___default().writeFileSync(fileUrl, JSON.stringify(accessToken));
    console.log("get access_token from server", accessToken.token);
};
const getAccessToken = async ()=>{
    const token = readAccessToken();
    if (token !== undefined) {
        return token;
    }
    await writeAccessToken();
    return readAccessToken() || "";
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    getAccessToken
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ aichat)
});

// EXTERNAL MODULE: ./components/sysconfig.ts
var sysconfig = __webpack_require__(567);
;// CONCATENATED MODULE: external "openai"
const external_openai_namespaceObject = require("openai");
;// CONCATENATED MODULE: ./components/aichat.ts


const configuration = new external_openai_namespaceObject.Configuration({
    apiKey: sysconfig/* default.openaiApiKey */.Z.openaiApiKey
});
const openai = new external_openai_namespaceObject.OpenAIApi(configuration);
const getReply = async (text)=>{
    try {
        const messages = [
            {
                role: external_openai_namespaceObject.ChatCompletionRequestMessageRoleEnum.Assistant,
                content: text
            }
        ];
        const response = await openai.createChatCompletion({
            model: sysconfig/* default.openaiModel */.Z.openaiModel,
            messages: messages,
            temperature: 1,
            max_tokens: 2000,
            presence_penalty: 0,
            stream: false
        }, {
            timeout: sysconfig/* default.openaiTimeout */.Z.openaiTimeout,
            timeoutErrorMessage: "提问超时，可能服务器正忙，请稍后重试",
            headers: {
                "Content-Encoding": "gzip",
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }
        });
        const reply = response.data.choices[0].message?.content.replace(/^\n+|\n+$/g, "");
        return reply || "没有找到答案，请问其他问题吧！";
    } catch (error) {
        console.error(`Error: ${error}`);
        return error.message || "没有找到答案，请问其他问题吧！";
    }
};
/* harmony default export */ const aichat = ({
    getReply
});


/***/ }),

/***/ 187:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export ReplyCache */
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_db__WEBPACK_IMPORTED_MODULE_0__]);
_db__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class ReplyCache {
    constructor(){
        this.getCache = (responseId)=>{
            const catche = _db__WEBPACK_IMPORTED_MODULE_0__/* .ReplyCacheModel.findOne */ .b.findOne({
                where: {
                    responseId: responseId
                },
                order: [
                    [
                        "createdAt",
                        "DESC"
                    ]
                ]
            });
            return catche;
        };
        this.saveCache = (fromusername, tousername, msgId, responseId, input, reply, expireAt)=>{
            const catche = _db__WEBPACK_IMPORTED_MODULE_0__/* .ReplyCacheModel.create */ .b.create({
                fromusername: fromusername,
                tousername: tousername,
                msgId: msgId,
                responseId: responseId,
                input: input,
                reply: reply,
                expireAt: expireAt
            });
            return catche;
        };
        this.findAll = ()=>_db__WEBPACK_IMPORTED_MODULE_0__/* .ReplyCacheModel.findAll */ .b.findAll();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new ReplyCache());

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 567:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const sysconfig = {
    appID: process.env.APP_ID || "",
    appSecret: process.env.APP_SECRET || "",
    token: process.env.TOKEN || "",
    openaiApiKey: process.env.OPENAI_API_KEY || "",
    subscribeReply: process.env.SUBSCRIBE_REPLY || "",
    contentTooLong: process.env.CONTENT_TOO_LONG || "",
    openaiModel: process.env.OPENAI_MODEL || "",
    encodingAESKey: process.env.ENCODING_AES_KEY || "",
    openaiTimeout: 60000,
    isAuthenticated: false,
    dbHost: process.env.DB_HOST || "",
    dbPort: 3306,
    dbUserName: process.env.DB_USER || "",
    dbPassword: process.env.DB_PASS || "",
    dbDatabase: process.env.DB_NAME || "",
    dbType: process.env.DB_TYPE || "mysql"
};
if (process.env.OPENAI_TIMEOUT !== undefined && /^\d+$/.test(process.env.OPENAI_TIMEOUT)) {
    sysconfig.openaiTimeout = parseInt(process.env.OPENAI_TIMEOUT);
}
if (process.env.DB_PORT !== undefined && /^\d+$/.test(process.env.DB_PORT)) {
    sysconfig.dbPort = parseInt(process.env.DB_PORT);
}
if (process.env.IS_AUTHENTICATED !== undefined && process.env.IS_AUTHENTICATED.toLowerCase() === "true") {
    sysconfig.isAuthenticated = true;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sysconfig);


/***/ }),

/***/ 675:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export SystemLog */
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_db__WEBPACK_IMPORTED_MODULE_0__]);
_db__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class SystemLog {
    constructor(){
        this.getLatestLogs = ()=>{
            return _db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.findAll */ .m.findAll({
                order: [
                    [
                        "createdAt",
                        "DESC"
                    ]
                ],
                limit: 100
            });
        };
        this.createLog = (fromusername, tousername, level, message)=>{
            const newRecord = _db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.create */ .m.create({
                fromusername: fromusername,
                tousername: tousername,
                message: message,
                level: level
            });
            return newRecord;
        };
        this.Log = (level, message)=>{
            const newRecord = _db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.create */ .m.create({
                message: message,
                level: level
            });
            return newRecord;
        };
        this.findAll = ()=>_db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.findAll */ .m.findAll();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new SystemLog());

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MK": () => (/* binding */ textMessage)
/* harmony export */ });
/* unused harmony exports imageMessage, voiceMessage, videoMessage, articleMessage */
// 回复文本消息
function textMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[text]]></MsgType>
    <Content><![CDATA[${message.reply}]]></Content>
    </xml>`;
}
// 回复图片消息
function imageMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[image]]></MsgType>
    <Image>
        <MediaId><![CDATA[${message.mediaId}]]></MediaId>
    </Image>
    </xml>`;
}
// 回复语音消息
function voiceMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[voice]]></MsgType>
    <Voice>
        <MediaId><![CDATA[${message.mediaId}]]></MediaId>
    </Voice>
    </xml>`;
}
// 回复视频消息
function videoMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[video]]></MsgType>
    <Video>
        <MediaId><![CDATA[${message.mediaId}]]></MediaId>
        <Title><![CDATA[${message.title}]]></Title>
        <Description><![CDATA[${message.description}]]></Description>
    </Video>
    </xml>`;
}
// 回复图文消息
function articleMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[news]]></MsgType>
    <ArticleCount>${message.articles?.length}</ArticleCount>
    <Articles>
        ${message.articles?.map((article)=>`<item><Title><![CDATA[${article.title}]]></Title>
                <Description><![CDATA[${article.description}]]></Description>
                <PicUrl><![CDATA[${article.img}]]></PicUrl>
                <Url><![CDATA[${article.url}]]></Url></item>`).join("")}
    </Articles>
    </xml>`;
}


/***/ }),

/***/ 895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _wxCrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(227);

function validateToken(req) {
    return new Promise((resolve, reject)=>{
        // 获取微信服务器发送的数据
        const { signature , timestamp , nonce , echostr  } = req.query;
        console.log(req.query);
        // sha1加密
        const result = (0,_wxCrypt__WEBPACK_IMPORTED_MODULE_0__/* .genSignature */ .CI)(timestamp, nonce);
        if (result === signature) {
            resolve(echostr || "");
        } else {
            reject(new Error("请求不是来自微信服务器，请接入公众号后台"));
        }
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validateToken);


/***/ }),

/***/ 227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Yz": () => (/* binding */ genResponseId),
  "CI": () => (/* binding */ genSignature),
  "Fr": () => (/* binding */ wxCrypt_wxBizMsgCrypt)
});

// UNUSED EXPORTS: default

// EXTERNAL MODULE: ./components/sysconfig.ts
var sysconfig = __webpack_require__(567);
;// CONCATENATED MODULE: external "crypto"
const external_crypto_namespaceObject = require("crypto");
;// CONCATENATED MODULE: ./components/wx/errorCode.ts
/**
 * error code 说明.
 *    0: 成功
 *    40001: 签名验证错误
 *    40002: xml解析失败
 *    40003: sha加密生成签名失败
 *    40004: encodingAesKey 非法
 *    40005: appid 校验错误
 *    40006: aes 加密失败
 *    40007: aes 解密失败
 *    40008: 解密后得到的buffer非法
 *    40009: base64加密失败
 *    40010: base64解密失败
 *    40011: 生成xml失败
 */ class ErrorCode {
    static{
        /**
   * 0 表示操作成功
   */ this.OK = 0;
    }
    static{
        /**
   * -40001 在验证签名时发生错误
   */ this.ValidateSignatureError = -40001;
    }
    static{
        /**
   * -40002 解析 XML 时发生错误
   */ this.ParseXmlError = -40002;
    }
    static{
        /**
   * -40003 在计算签名时发生错误
   */ this.ComputeSignatureError = -40003;
    }
    static{
        /**
   * -40004 非法 AES 密钥
   */ this.IllegalAesKey = -40004;
    }
    static{
        /**
   * -40005 验证 AppId 失败
   */ this.ValidateAppidError = -40005;
    }
    static{
        /**
   * -40006 加密消息时发生错误
   */ this.EncryptAESError = -40006;
    }
    static{
        /**
   * -40007 解密消息时发生错误
   */ this.DecryptAESError = -40007;
    }
    static{
        /**
   * -40008 非法缓冲区
   */ this.IllegalBuffer = -40008;
    }
    static{
        /**
   * -40009 将数据编码为 Base64 字符串时发生错误
   */ this.EncodeBase64Error = -40009;
    }
    static{
        /**
   * -40010 将 Base64 字符串解码为数据时发生错误
   */ this.DecodeBase64Error = -40010;
    }
    static{
        /**
   * -40011 生成返回结果的 XML 时发生错误
   */ this.GenReturnXmlError = -40011;
    }
}
function getErrorMsg(code) {
    switch(code){
        case ErrorCode.OK:
            return "操作成功";
        case ErrorCode.ValidateSignatureError:
            return "验证签名时发生错误";
        case ErrorCode.ParseXmlError:
            return "解析 XML 时发生错误";
        case ErrorCode.ComputeSignatureError:
            return "计算签名时发生错误";
        case ErrorCode.IllegalAesKey:
            return "非法 AES 密钥";
        case ErrorCode.ValidateAppidError:
            return "验证 AppId 失败";
        case ErrorCode.EncryptAESError:
            return "加密消息时发生错误";
        case ErrorCode.DecryptAESError:
            return "解密消息时发生错误";
        case ErrorCode.IllegalBuffer:
            return "非法缓冲区";
        case ErrorCode.EncodeBase64Error:
            return "将数据编码为 Base64 字符串时发生错误";
        case ErrorCode.DecodeBase64Error:
            return "将 Base64 字符串解码为数据时发生错误";
        case ErrorCode.GenReturnXmlError:
            return "生成返回结果的 XML 时发生错误";
        default:
            return "未知错误";
    }
}

;// CONCATENATED MODULE: ./components/wx/pkcs7Encoder.ts
/**
 * PKCS7Encoder class
 *
 * 提供基于 PKCS7 算法的加解密接口.
 */ class PKCS7Encoder {
    static{
        this.block_size = 32;
    }
    /**
   * 对需要加密的明文进行填充补位
   * @param text 需要进行填充补位操作的明文
   * @returns 补齐明文字符串
   */ encode(text) {
        const block_size = PKCS7Encoder.block_size;
        const text_length = text.length;
        // 计算需要填充的位数
        let amount_to_pad = PKCS7Encoder.block_size - text_length % PKCS7Encoder.block_size;
        if (amount_to_pad === 0) {
            amount_to_pad = PKCS7Encoder.block_size;
        }
        // 获得补位所用的字符
        const pad_chr = String.fromCharCode(amount_to_pad);
        let tmp = "";
        for(let index = 0; index < amount_to_pad; index++){
            tmp += pad_chr;
        }
        return text + tmp;
    }
    /**
   * 对解密后的明文进行补位删除
   * @param decrypted 解密后的明文
   * @returns 删除填充补位后的明文
   */ decode(text) {
        let pad = text.charCodeAt(text.length - 1);
        if (pad < 1 || pad > 32) {
            pad = 0;
        }
        return text.slice(0, text.length - pad);
    }
}

;// CONCATENATED MODULE: ./components/wx/prpcrypt.ts



/**
 * Prpcrypt class
 *
 * 提供接收和推送给公众平台消息的加解密接口.
 */ class Prpcrypt {
    constructor(k){
        this.key = Buffer.from(k + "=", "base64");
    }
    /**
     * 对明文进行加密
     * @param text 需要加密的明文
     * @param appid 
     * @returns 加密后的密文
     */ encrypt(text, appid) {
        try {
            // 获得 16 位随机字符串，填充到明文之前
            const random = this.getRandomStr();
            text = random + Buffer.from(text).length.toString() + text + appid;
            // 网络字节序
            const size = 16;
            const iv = this.key.slice(0, 16);
            // 使用自定义的填充方式对明文进行补位填充
            const pkc_encoder = new PKCS7Encoder();
            const encodedText = pkc_encoder.encode(text);
            const cipher = (0,external_crypto_namespaceObject.createCipheriv)("AES-256-CBC", this.key, iv);
            // 加密
            let encrypted = cipher.update(encodedText, "utf8", "base64");
            encrypted += cipher.final("base64");
            // 使用 BASE64 对加密后的字符串进行编码
            return [
                ErrorCode.OK,
                encrypted
            ];
        } catch (e) {
            // console.log(e);
            return [
                ErrorCode.EncryptAESError,
                getErrorMsg(ErrorCode.EncryptAESError)
            ];
        }
    }
    /**
     * 对密文进行解密
     * @param encrypted 需要解密的密文
     * @param appid 
     * @returns 解密得到的明文
     */ decrypt(encrypted, appid) {
        try {
            // 使用 BASE64 对需要解密的字符串进行解码
            const cipher = (0,external_crypto_namespaceObject.createDecipheriv)("AES-256-CBC", this.key, this.key.slice(0, 16));
            const decipher = Buffer.concat([
                cipher.update(encrypted, "base64"),
                cipher.final()
            ]);
            // 去除补位字符
            const pkc_encoder = new PKCS7Encoder();
            const result = pkc_encoder.decode(decipher.toString("utf8"));
            // 去除 16 位随机字符串，网络字节序和 AppId
            if (result.length < 16) {
                return [
                    ErrorCode.IllegalBuffer,
                    getErrorMsg(ErrorCode.IllegalBuffer)
                ];
            }
            const content = result.slice(19);
            const xml_len = content.length;
            const from_appid = content.substring(xml_len - appid.length);
            const xmlContent = content.slice(0, xml_len - appid.length);
            if (from_appid !== appid) {
                return [
                    ErrorCode.ValidateAppidError,
                    getErrorMsg(ErrorCode.ValidateAppidError)
                ];
            }
            return [
                ErrorCode.OK,
                xmlContent
            ];
        } catch (e) {
            console.log(e);
            return [
                ErrorCode.DecryptAESError,
                getErrorMsg(ErrorCode.DecryptAESError)
            ];
        }
    }
    /**
     * 随机生成 16 位字符串
     * @returns 生成的字符串
     */ getRandomStr() {
        const str_pol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
        const max = str_pol.length - 1;
        let str = "";
        for(let i = 0; i < 16; i++){
            str += str_pol.charAt(Math.floor(Math.random() * max));
        }
        return str;
    }
}

;// CONCATENATED MODULE: external "sha1"
const external_sha1_namespaceObject = require("sha1");
var external_sha1_default = /*#__PURE__*/__webpack_require__.n(external_sha1_namespaceObject);
;// CONCATENATED MODULE: ./components/wx/sha1.ts


/**
 * SHA1 class
 *
 * 计算公众平台的消息签名接口.
 */ class SHA1 {
    /**
   * 用SHA1算法生成安全签名
   * @param token 票据
   * @param timestamp 时间戳
   * @param nonce 随机字符串
   * @param encrypt_msg 密文消息
   * @returns [ErrorCode: number,SHA1 string | null]如果计算成功，返回安全签名，否则返回错误码。
   */ getSHA1(token, timestamp, nonce, encrypt_msg) {
        try {
            const array = [
                token,
                timestamp,
                nonce
            ];
            array.sort();
            const str = array.join("");
            return [
                ErrorCode.OK,
                external_sha1_default()(str)
            ];
        } catch (e) {
            //console.log(e);
            return [
                ErrorCode.ComputeSignatureError,
                getErrorMsg(ErrorCode.ComputeSignatureError)
            ];
        }
    }
}

;// CONCATENATED MODULE: external "xmldom"
const external_xmldom_namespaceObject = require("xmldom");
;// CONCATENATED MODULE: ./components/wx/xmlparse.ts


/**
 * XMLParse class
 *
 * 提供提取消息格式中的密文及生成回复消息格式的接口.
 */ class XMLParse {
    /**
   * 提取出xml数据包中的加密消息
   * @param xmltext 待提取的xml字符串
   * @returns [ErrorCode:number, encrypt:string | null,tousername: string | null]提取出的加密消息字符串
   */ extract(xmltext) {
        try {
            const parser = new external_xmldom_namespaceObject.DOMParser();
            const xmlDoc = parser.parseFromString(xmltext, "text/xml");
            const encrypt = xmlDoc.getElementsByTagName("Encrypt")[0]?.textContent || "";
            const tousername = xmlDoc.getElementsByTagName("ToUserName")[0]?.textContent || "";
            return [
                ErrorCode.OK,
                encrypt,
                tousername
            ];
        } catch (error) {
            // console.log(error);
            return [
                ErrorCode.ParseXmlError,
                null,
                null
            ];
        }
    }
    parse(xmltext) {
        try {
            const parser = new external_xmldom_namespaceObject.DOMParser();
            const xmlDoc = parser.parseFromString(xmltext, "text/xml");
            const xml = {
                encrypt: xmlDoc.getElementsByTagName("Encrypt")[0]?.textContent || "",
                tousername: xmlDoc.getElementsByTagName("ToUserName")[0]?.textContent || "",
                fromusername: xmlDoc.getElementsByTagName("FromUserName")[0]?.textContent || "",
                msgtype: xmlDoc.getElementsByTagName("MsgType")[0]?.textContent || "",
                content: xmlDoc.getElementsByTagName("Content")[0]?.textContent || "",
                msgid: xmlDoc.getElementsByTagName("MsgId")[0]?.textContent || "",
                createtime: Number.parseInt(xmlDoc.getElementsByTagName("CreateTime")[0]?.textContent || "0"),
                event: xmlDoc.getElementsByTagName("Event")[0]?.textContent || "",
                eventkey: xmlDoc.getElementsByTagName("EventKey")[0]?.textContent || ""
            };
            return [
                ErrorCode.OK,
                xml
            ];
        } catch (error) {
            // console.log(error);
            return [
                ErrorCode.ParseXmlError,
                null
            ];
        }
    }
    /**
   * 生成xml消息
   * @param encrypt 加密后的消息密文
   * @param signature 安全签名
   * @param timestamp 时间戳
   * @param nonce 随机字符串
   * @returns xml格式的加密消息
   */ generate(encrypt, signature, timestamp, nonce) {
        const format = `<xml>
<Encrypt><![CDATA[${encrypt}]]></Encrypt>
<MsgSignature><![CDATA[${signature}]]></MsgSignature>
<TimeStamp>${timestamp}</TimeStamp>
<Nonce><![CDATA[${nonce}]]></Nonce>
</xml>`;
        return format;
    }
}

;// CONCATENATED MODULE: ./components/wx/wxBizMsgCrypt.ts




/**
 * 1.第三方回复加密消息给公众平台；
 * 2.第三方收到公众平台发送的消息，验证消息的安全性，并对消息进行解密。
 */ class WXBizMsgCrypt {
    /**
   * 构造函数
   * @param token 公众平台上，开发者设置的token
   * @param encodingAesKey 公众平台上，开发者设置的EncodingAESKey
   * @param appId 公众平台的appId
   */ constructor(token, encodingAesKey, appId){
        this.token = token;
        this.encodingAesKey = encodingAesKey;
        this.appId = appId;
    }
    /**
   * 将公众平台回复用户的消息加密打包.
   * <ol>
   *    <li>对要发送的消息进行AES-CBC加密</li>
   *    <li>生成安全签名</li>
   *    <li>将消息密文和安全签名打包成xml格式</li>
   * </ol>
   *
   * @param replyMsg 公众平台待回复用户的消息，xml格式的字符串
   * @param timeStamp 时间戳，可以自己生成，也可以用URL参数的timestamp
   * @param nonce 随机串，可以自己生成，也可以用URL参数的nonce
   * @param encryptMsg 加密后的可以直接回复用户的密文，包括msg_signature, timestamp, nonce, encrypt的xml格式的字符串,
   *                      当return返回0时有效
   *
   * @return [number, string] 成功0，失败返回对应的错误码
   */ encryptMsg(replyMsg, timeStamp, nonce) {
        const pc = new Prpcrypt(this.encodingAesKey);
        //加密
        const [ret, encrypt] = pc.encrypt(replyMsg, this.appId);
        if (ret !== 0) {
            return [
                ret,
                getErrorMsg(ret)
            ];
        }
        if (timeStamp == null) {
            timeStamp = new Date().getTime().toString();
        }
        //生成安全签名
        const sha1 = new SHA1();
        const [errCode, signature] = sha1.getSHA1(this.token, timeStamp, nonce, encrypt);
        if (errCode !== 0) {
            return [
                errCode,
                getErrorMsg(errCode)
            ];
        }
        const signatureStr = signature;
        //生成发送的xml
        const xmlparse = new XMLParse();
        const encryptMsg = xmlparse.generate(encrypt, signatureStr, timeStamp, nonce);
        return [
            ErrorCode.OK,
            encryptMsg
        ];
    }
    /**
   * 检验消息的真实性，并且获取解密后的明文.
   * <ol>
   *    <li>利用收到的密文生成安全签名，进行签名验证</li>
   *    <li>若验证通过，则提取xml中的加密消息</li>
   *    <li>对消息进行解密</li>
   * </ol>
   *
   * @param msgSignature 签名串，对应URL参数的msg_signature
   * @param timestamp 时间戳 对应URL参数的timestamp
   * @param nonce 随机串，对应URL参数的nonce
   * @param postData 密文，对应POST请求的数据
   *
   * @return [number, string] 成功0，失败返回对应的错误码
   */ decryptMsg(msgSignature, timestamp, nonce, postData) {
        if (this.encodingAesKey.length !== 43) {
            return [
                ErrorCode.IllegalAesKey,
                ""
            ];
        }
        const pc = new Prpcrypt(this.encodingAesKey);
        //提取密文
        const xmlparse = new XMLParse();
        const [ret, encrypt, touser_name] = xmlparse.extract(postData);
        if (ret !== 0) {
            return [
                ret,
                getErrorMsg(ret)
            ];
        }
        if (timestamp == null) {
            timestamp = new Date().getTime().toString();
        }
        const encryptStr = encrypt;
        //验证安全签名
        const sha1 = new SHA1();
        const [ret1, signature] = sha1.getSHA1(this.token, timestamp, nonce, encryptStr);
        if (ret1 !== 0) {
            return [
                ret1,
                getErrorMsg(ret1)
            ];
        }
        if (signature !== msgSignature) {
            console.log(`signature !== msgSignature:${signature} !== ${msgSignature}`);
            return [
                ErrorCode.ValidateSignatureError,
                getErrorMsg(ErrorCode.ValidateSignatureError)
            ];
        }
        const [result, msg] = pc.decrypt(encryptStr, this.appId);
        console.log("msg1:", msg);
        if (result !== 0) {
            return [
                result,
                getErrorMsg(result)
            ];
        }
        return [
            ErrorCode.OK,
            msg
        ];
    }
    parseFromString(body) {
        const xmlparse = new XMLParse();
        return xmlparse.parse(body);
    }
}
/* harmony default export */ const wxBizMsgCrypt = (WXBizMsgCrypt);

;// CONCATENATED MODULE: ./components/wxCrypt.ts




const genSignature = (timestamp, nonce)=>{
    const sortedArr = [
        sysconfig/* default.token */.Z.token,
        timestamp,
        nonce
    ].sort().join("");
    // sha1加密
    const signature = external_sha1_default()(sortedArr);
    return signature;
};
const genResponseId = (seed)=>{
    return external_crypto_namespaceObject.createHash("md5") // 使用 MD5 散列算法
    .update(seed).digest("hex").substr(0, 4); // 生成 4 位随机数
};
const wxCrypt_wxBizMsgCrypt = new wxBizMsgCrypt(sysconfig/* default.token */.Z.token, sysconfig/* default.encodingAESKey */.Z.encodingAESKey, sysconfig/* default.appID */.Z.appID);
/* harmony default export */ const wxCrypt = ({
    wxBizMsgCrypt: wxCrypt_wxBizMsgCrypt,
    genSignature,
    genResponseId
});


/***/ }),

/***/ 612:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ ReplyCacheModel),
/* harmony export */   "m": () => (/* binding */ SystemLogModel)
/* harmony export */ });
/* harmony import */ var _sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(934);
/* harmony import */ var _models_system_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(713);
/* harmony import */ var _models_reply_cache__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(411);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sequelize__WEBPACK_IMPORTED_MODULE_0__, _models_system_log__WEBPACK_IMPORTED_MODULE_1__, _models_reply_cache__WEBPACK_IMPORTED_MODULE_2__]);
([_sequelize__WEBPACK_IMPORTED_MODULE_0__, _models_system_log__WEBPACK_IMPORTED_MODULE_1__, _models_reply_cache__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// index.ts



const SystemLogModel = (0,_models_system_log__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(_sequelize__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
const ReplyCacheModel = (0,_models_reply_cache__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_sequelize__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
// sequelize.sync({ force: true }).then(() => {
//     console.log('数据库同步成功');
// }).catch((err) => {
//     console.error('数据库同步失败:',err);
// });


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 411:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(210);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__]);
sequelize__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(sequelize) {
    const attributes = {
        id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
            comment: undefined,
            field: "id"
        },
        fromusername: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: true,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "fromusername"
        },
        tousername: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: true,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "tousername"
        },
        msgId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "msgId"
        },
        responseId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "responseId"
        },
        input: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.TEXT,
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "input"
        },
        reply: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.TEXT,
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "reply"
        },
        createdAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "createdAt"
        },
        updatedAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "updatedAt"
        },
        expireAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "expireAt"
        }
    };
    const options = {
        tableName: "reply_cache",
        comment: "",
        indexes: []
    };
    const ReplyCacheModel = sequelize.define("reply_cache", attributes, options);
    return ReplyCacheModel;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 713:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(210);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__]);
sequelize__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(sequelize) {
    const attributes = {
        id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER.UNSIGNED,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
            comment: undefined,
            field: "id"
        },
        level: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.ENUM("error", "warn", "info", "debug"),
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "level"
        },
        fromusername: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: true,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "fromusername"
        },
        tousername: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: true,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "tousername"
        },
        message: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.TEXT,
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "message"
        },
        createdAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "createdAt"
        },
        updatedAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "updatedAt"
        }
    };
    const options = {
        tableName: "system_log",
        comment: "",
        indexes: []
    };
    const SystemLogModel = sequelize.define("system_log", attributes, options);
    return SystemLogModel;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 934:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(210);
/* harmony import */ var _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(567);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__]);
sequelize__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// sequelize.ts


// 创建 Sequelize 实例并传递连接参数
const dialect = _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbType */ .Z.dbType;
console.log("dialect:", dialect);
let sequelize = new sequelize__WEBPACK_IMPORTED_MODULE_0__.Sequelize({
    host: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbHost */ .Z.dbHost,
    username: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbUserName */ .Z.dbUserName,
    password: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbPassword */ .Z.dbPassword,
    database: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbDatabase */ .Z.dbDatabase,
    port: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbPort */ .Z.dbPort,
    dialect: dialect
});
// 导出 sequelize 实例
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sequelize);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 555:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_aichat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(200);
/* harmony import */ var _components_validateToken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(895);
/* harmony import */ var _components_template__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(545);
/* harmony import */ var _components_sysconfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(648);
/* harmony import */ var _components_accessToken__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(684);
/* harmony import */ var _components_replyCache__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(187);
/* harmony import */ var _components_systemLog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(675);
/* harmony import */ var _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(227);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__, _components_accessToken__WEBPACK_IMPORTED_MODULE_4__, _components_replyCache__WEBPACK_IMPORTED_MODULE_5__, _components_systemLog__WEBPACK_IMPORTED_MODULE_6__]);
([axios__WEBPACK_IMPORTED_MODULE_3__, _components_accessToken__WEBPACK_IMPORTED_MODULE_4__, _components_replyCache__WEBPACK_IMPORTED_MODULE_5__, _components_systemLog__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









async function handleTextMessage(xml, res, isEncrypt, sMsgTimestamp, sMsgNonce) {
    if (!xml || !xml.msgid || !xml.fromusername || !xml.tousername || !xml.content) {
        _components_systemLog__WEBPACK_IMPORTED_MODULE_6__/* ["default"].createLog */ .Z.createLog(xml.fromusername, xml.tousername, "error", `${JSON.stringify(xml)}`); // 输出无效的XML对象
        return;
    }
    const expireAt = new Date(Date.now() + 20 * 1000);
    const timestamp = Date.now(); // 当前时间戳
    const seed = `${timestamp}_${xml.FromUserName}`; // 种子为时间戳和用户的唯一标识符
    const responseId = (0,_components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .genResponseId */ .Yz)(seed); // 生成 4 位随机数
    // 查询缓存
    const idRegExp = /^([0-9a-zA-Z]{4}|\[[0-9a-zA-Z]{4}\]|【[0-9a-zA-Z]{4}】)$/; // 匹配四位数字、[四位数字]、【四位数字】
    let result = "";
    let cache = null;
    if (idRegExp.test(xml.content)) {
        const regulatedStr = xml.content.replace(/[【】[\]]/g, ""); // 替换方括号和圆括号为空字符串
        const rows = await _components_replyCache__WEBPACK_IMPORTED_MODULE_5__/* ["default"].getCache */ .Z.getCache(regulatedStr);
        if (Array.isArray(rows)) {
            cache = rows[0];
            rows.forEach((row)=>{
                const { reply  } = row;
                if (reply) {
                    result += `${reply}\n`; // 添加换行符 `\n`
                }
            });
        } else {
            const { reply  } = rows; // 单个对象
            cache = rows;
            if (reply) {
                result = `${reply}`;
            }
        }
        console.log("rows:", rows);
    }
    if (cache) {
        // 如果缓存存在且未过期，直接返回响应
        let message;
        if (result) {
            message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: result
            };
        } else {
            message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: "正在处理，请稍后..."
            };
        }
        if (isEncrypt) {
            const [c, d] = _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .wxBizMsgCrypt.encryptMsg */ .Fr.encryptMsg((0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message), sMsgTimestamp, sMsgNonce);
            res.send(d);
        } else {
            res.send((0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message));
        }
    } else {
        // 如果缓存不存在或已过期，则查询 AI Chat Bot 并保存缓存和请求
        const newRecord = await _components_replyCache__WEBPACK_IMPORTED_MODULE_5__/* ["default"].saveCache */ .Z.saveCache(xml.fromusername, xml.tousername, xml.msgid, responseId, xml.content, null, expireAt); // 将响应 ID 插入数据库
        let message;
        if (_components_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].isAuthenticated */ .Z.isAuthenticated === true) {
            message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: `正在处理【${responseId}】，请稍后得到结果后会马上反馈给您！`
            };
        } else {
            message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: `正在处理，由于公众号还没有认证，请稍后发送【${responseId}】获取结果`
            };
        }
        if (isEncrypt) {
            const [c, d] = _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .wxBizMsgCrypt.encryptMsg */ .Fr.encryptMsg((0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message), sMsgTimestamp, sMsgNonce);
            res.send(d);
        } else {
            res.send((0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message));
        }
        const reply = await _components_aichat__WEBPACK_IMPORTED_MODULE_0__/* ["default"].getReply */ .Z.getReply(xml.content);
        await newRecord.update({
            reply: reply
        }); // 将响应数据更新到数据库
        if (_components_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].isAuthenticated */ .Z.isAuthenticated === true) {
            try {
                let replyXmlMessage = "";
                if (isEncrypt) {
                    const [c, d] = _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .wxBizMsgCrypt.encryptMsg */ .Fr.encryptMsg((0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message), sMsgTimestamp, sMsgNonce);
                    replyXmlMessage = d;
                } else {
                    replyXmlMessage = (0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message);
                }
                const AccessToken = await (0,_components_accessToken__WEBPACK_IMPORTED_MODULE_4__/* .getAccessToken */ .h)();
                const replyRes = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].post(`https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=${AccessToken}`, replyXmlMessage, {
                    headers: {
                        "Content-Type": "text/xml;charset=utf-8",
                        "Content-Length": Buffer.byteLength(replyXmlMessage, "utf8")
                    }
                });
                _components_systemLog__WEBPACK_IMPORTED_MODULE_6__/* ["default"].createLog */ .Z.createLog(xml.fromusername, xml.tousername, "info", `${JSON.stringify(replyRes)}`);
            } catch (error) {
                _components_systemLog__WEBPACK_IMPORTED_MODULE_6__/* ["default"].createLog */ .Z.createLog(xml.fromusername, xml.tousername, "error", `${JSON.stringify(error)}`);
            }
        }
    }
}
async function handleSubscribeEvent(xml, res) {
    const message = {
        FromUserName: xml.fromusername,
        ToUserName: xml.tousername,
        reply: _components_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].subscribeReply */ .Z.subscribeReply
    };
    res.send((0,_components_template__WEBPACK_IMPORTED_MODULE_8__/* .textMessage */ .MK)(message).toString());
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    const { method  } = req;
    const { signature , timestamp , nonce , echostr , encrypt_type , msg_signature  } = req.query;
    const sMsgTimestamp = timestamp;
    const sMsgNonce = nonce;
    const msgSignature = signature;
    let result;
    try {
        result = await (0,_components_validateToken__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(req);
        console.info(result);
    } catch (error) {
        console.error(error.message);
    }
    switch(method){
        case "GET":
            res.send(result);
            break;
        case "POST":
            const sMsg = req.body;
            console.log("req.query:", req.query);
            console.log(typeof sMsg);
            console.log("req.body:", sMsg);
            let [co, xml] = _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .wxBizMsgCrypt.parseFromString */ .Fr.parseFromString(sMsg);
            let isEncrypt = false;
            if (xml?.encrypt && !xml?.content) {
                isEncrypt = true;
                const [dc, decryptedMessage] = _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .wxBizMsgCrypt.decryptMsg */ .Fr.decryptMsg(msgSignature, sMsgTimestamp, sMsgNonce, sMsg);
                let [_, xmls] = _components_wxCrypt__WEBPACK_IMPORTED_MODULE_7__/* .wxBizMsgCrypt.parseFromString */ .Fr.parseFromString(decryptedMessage);
                xml = xmls;
            }
            const msgType = xml?.msgtype;
            switch(msgType){
                case "text":
                    await handleTextMessage(xml, res, isEncrypt, msgSignature, sMsgNonce);
                    break;
                case "event":
                    switch(xml?.event){
                        case "subscribe":
                            await handleSubscribeEvent(xml, res);
                            break;
                        case "unsubscribe":
                        default:
                            res.send("");
                            break;
                    }
                    break;
                default:
                    res.send("");
                    break;
            }
            break;
        default:
            res.setHeader("Allow", [
                "GET",
                "POST"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
            break;
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(555));
module.exports = __webpack_exports__;

})();