"use strict";
(() => {
var exports = {};
exports.id = 764;
exports.ids = [764];
exports.modules = {

/***/ 702:
/***/ ((module) => {

module.exports = require("sha1");

/***/ }),

/***/ 435:
/***/ ((module) => {

module.exports = require("xmldom");

/***/ }),

/***/ 648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 558:
/***/ ((module) => {

module.exports = import("js-base64");;

/***/ }),

/***/ 210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 500:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ getAccessToken)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(648);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sysconfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fileUrl = "./access_token.json";
const readAccessToken = ()=>{
    try {
        const accessTokenStr = fs__WEBPACK_IMPORTED_MODULE_1___default().readFileSync(fileUrl, "utf8");
        const accessToken = JSON.parse(accessTokenStr);
        const expireTime = new Date(accessToken.expireTime).getTime();
        const currentTime = new Date().getTime();
        if (accessToken.token && expireTime > currentTime) {
            console.log("get access_token from local file", accessToken.token);
            return accessToken.token;
        }
        console.log("access_token expired");
        return undefined;
    } catch (e) {
        console.log("read access_token error:", e.message);
        return undefined;
    }
};
const writeAccessToken = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].appID */ .Z.appID}&secret=${_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].appSecret */ .Z.appSecret}`);
    if (!res.data.access_token || !res.data.expires_in) {
        console.error("ACCESS_TOKEN为空", res.data);
        throw new Error("access_token为空");
    }
    const now = new Date();
    const expireTime = now.getTime() + res.data.expires_in * 1000;
    const accessToken = {
        token: res.data.access_token,
        expireTime: expireTime
    };
    fs__WEBPACK_IMPORTED_MODULE_1___default().writeFileSync(fileUrl, JSON.stringify(accessToken));
    console.log("get access_token from server", accessToken.token);
};
const getAccessToken = async ()=>{
    const token = readAccessToken();
    if (token !== undefined) {
        return token;
    }
    await writeAccessToken();
    return readAccessToken() || "";
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    getAccessToken
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 401:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ aichat)
});

// EXTERNAL MODULE: ./components/sysconfig.ts + 1 modules
var sysconfig = __webpack_require__(71);
;// CONCATENATED MODULE: external "openai"
const external_openai_namespaceObject = require("openai");
;// CONCATENATED MODULE: ./components/aichat.ts


const configuration = new external_openai_namespaceObject.Configuration({
    apiKey: sysconfig/* default.openaiApiKey */.Z.openaiApiKey
});
const openai = new external_openai_namespaceObject.OpenAIApi(configuration);
const getReply = async (text)=>{
    try {
        const messages = [
            {
                role: external_openai_namespaceObject.ChatCompletionRequestMessageRoleEnum.Assistant,
                content: text
            }
        ];
        const response = await openai.createChatCompletion({
            model: sysconfig/* default.openaiModel */.Z.openaiModel,
            messages: messages,
            temperature: 1,
            max_tokens: 2000,
            presence_penalty: 0,
            stream: false
        }, {
            timeout: sysconfig/* default.openaiTimeout */.Z.openaiTimeout,
            timeoutErrorMessage: "提问超时，可能服务器正忙，请稍后重试",
            headers: {
                "Content-Encoding": "gzip",
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }
        });
        const reply = response.data.choices[0].message?.content.replace(/^\n+|\n+$/g, "");
        return reply || "没有找到答案，请问其他问题吧！";
    } catch (error) {
        console.error(`Error: ${error}`);
        return error.message || "没有找到答案，请问其他问题吧！";
    }
};
/* harmony default export */ const aichat = ({
    getReply
});


/***/ }),

/***/ 382:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export ReplyCache */
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(100);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_db__WEBPACK_IMPORTED_MODULE_0__]);
_db__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class ReplyCache {
    constructor(){
        this.getCache = (msgId, responseId)=>{
            const catche = _db__WEBPACK_IMPORTED_MODULE_0__/* .ReplyCacheModel.findOne */ .b.findOne({
                where: {
                    msgId: msgId,
                    responseId: responseId
                }
            });
            return catche;
        };
        this.saveCache = (msgId, responseId, input, reply, expireAt)=>{
            const catche = _db__WEBPACK_IMPORTED_MODULE_0__/* .ReplyCacheModel.create */ .b.create({
                msgId: msgId,
                responseId: responseId,
                input: input,
                reply: reply,
                expireAt: expireAt
            });
            return catche;
        };
        this.findAll = ()=>_db__WEBPACK_IMPORTED_MODULE_0__/* .ReplyCacheModel.findAll */ .b.findAll();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new ReplyCache());

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 71:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_sysconfig)
});

;// CONCATENATED MODULE: external "dotenv"
const external_dotenv_namespaceObject = require("dotenv");
var external_dotenv_default = /*#__PURE__*/__webpack_require__.n(external_dotenv_namespaceObject);
;// CONCATENATED MODULE: ./components/sysconfig.ts

external_dotenv_default().config();
const sysconfig = {
    appID: process.env.APP_ID || "",
    appSecret: process.env.APP_SECRET || "",
    token: process.env.TOKEN || "",
    openaiApiKey: process.env.OPENAI_API_KEY || "",
    subscribeReply: process.env.SUBSCRIBE_REPLY || "",
    contentTooLong: process.env.CONTENT_TOO_LONG || "",
    openaiModel: process.env.OPENAI_MODEL || "",
    encodingAESKey: process.env.ENCODING_AES_KEY || "",
    openaiTimeout: 60000,
    isAuthenticated: false,
    dbHost: process.env.DB_HOST || "",
    dbPort: 3306,
    dbUserName: process.env.DB_USER || "",
    dbPassword: process.env.DB_PASS || "",
    dbDatabase: process.env.DB_NAME || "",
    dbType: process.env.DB_TYPE || "mysql"
};
if (process.env.OPENAI_TIMEOUT !== undefined && /^\d+$/.test(process.env.OPENAI_TIMEOUT)) {
    sysconfig.openaiTimeout = parseInt(process.env.OPENAI_TIMEOUT);
}
if (process.env.DB_PORT !== undefined && /^\d+$/.test(process.env.DB_PORT)) {
    sysconfig.dbPort = parseInt(process.env.DB_PORT);
}
if (process.env.IS_AUTHENTICATED !== undefined && process.env.IS_AUTHENTICATED.toLowerCase() === "true") {
    sysconfig.isAuthenticated = true;
}
/* harmony default export */ const components_sysconfig = (sysconfig);


/***/ }),

/***/ 502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export SystemLog */
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(100);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_db__WEBPACK_IMPORTED_MODULE_0__]);
_db__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

class SystemLog {
    constructor(){
        this.getLatestLogs = ()=>{
            return _db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.findAll */ .m.findAll({
                order: [
                    [
                        "createdAt",
                        "DESC"
                    ]
                ],
                limit: 100
            });
        };
        this.createLog = (level, message)=>{
            const newRecord = _db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.create */ .m.create({
                message: message,
                level: level
            });
            return newRecord;
        };
        this.findAll = ()=>_db__WEBPACK_IMPORTED_MODULE_0__/* .SystemLogModel.findAll */ .m.findAll();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new SystemLog());

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 463:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MK": () => (/* binding */ textMessage)
/* harmony export */ });
/* unused harmony exports imageMessage, voiceMessage, videoMessage, articleMessage */
// 回复文本消息
function textMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[text]]></MsgType>
    <Content><![CDATA[${message.reply}]]></Content>
    </xml>`;
}
// 回复图片消息
function imageMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[image]]></MsgType>
    <Image>
        <MediaId><![CDATA[${message.mediaId}]]></MediaId>
    </Image>
    </xml>`;
}
// 回复语音消息
function voiceMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[voice]]></MsgType>
    <Voice>
        <MediaId><![CDATA[${message.mediaId}]]></MediaId>
    </Voice>
    </xml>`;
}
// 回复视频消息
function videoMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[video]]></MsgType>
    <Video>
        <MediaId><![CDATA[${message.mediaId}]]></MediaId>
        <Title><![CDATA[${message.title}]]></Title>
        <Description><![CDATA[${message.description}]]></Description>
    </Video>
    </xml>`;
}
// 回复图文消息
function articleMessage(message) {
    const createTime = new Date().getTime();
    return `<xml>
    <ToUserName><![CDATA[${message.FromUserName}]]></ToUserName>
    <FromUserName><![CDATA[${message.ToUserName}]]></FromUserName>
    <CreateTime>${createTime}</CreateTime>
    <MsgType><![CDATA[news]]></MsgType>
    <ArticleCount>${message.articles?.length}</ArticleCount>
    <Articles>
        ${message.articles?.map((article)=>`<item><Title><![CDATA[${article.title}]]></Title>
                <Description><![CDATA[${article.description}]]></Description>
                <PicUrl><![CDATA[${article.img}]]></PicUrl>
                <Url><![CDATA[${article.url}]]></Url></item>`).join("")}
    </Articles>
    </xml>`;
}


/***/ }),

/***/ 957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _wxcrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(120);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_wxcrypt__WEBPACK_IMPORTED_MODULE_0__]);
_wxcrypt__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function validateToken(req) {
    return new Promise((resolve, reject)=>{
        // 获取微信服务器发送的数据
        const { signature , timestamp , nonce , echostr  } = req.query;
        // sha1加密
        const result = (0,_wxcrypt__WEBPACK_IMPORTED_MODULE_0__/* .genSignature */ .CI)(timestamp, nonce);
        if (result === signature) {
            resolve(echostr || "");
        } else {
            reject(new Error("请求不是来自微信服务器，请接入公众号后台"));
        }
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validateToken);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CI": () => (/* binding */ genSignature)
/* harmony export */ });
/* unused harmony exports Pkcs7Encoder, Pkcs7Decoder */
/* harmony import */ var _sysconfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71);
/* harmony import */ var sha1__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(702);
/* harmony import */ var sha1__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sha1__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_base64__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(558);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_base64__WEBPACK_IMPORTED_MODULE_2__]);
js_base64__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




class Pkcs7Encoder {
    encode(content) {
        let buffer;
        if (typeof content === "string") {
            buffer = Buffer.from(content);
        } else {
            buffer = content;
        }
        const len = buffer.length;
        const amountToPad = 32 - len % 32;
        const result = Buffer.allocUnsafe(len + amountToPad);
        buffer.copy(result);
        result.fill(amountToPad, len);
        return result;
    }
}
class Pkcs7Decoder {
    decode(ciphertext, encoding) {
        const content = Buffer.from(ciphertext, encoding);
        const padLength = content[content.length - 1];
        return content.slice(0, content.length - padLength);
    }
    strip(content) {
        const padSize = content[content.byteLength - 1];
        if (padSize < 1 || padSize > 32 || padSize > content.byteLength) {
            return null;
        }
        for(let i = padSize; i > 0; i--){
            if (content[content.byteLength - i] !== padSize) {
                return null;
            }
        }
        return content.slice(0, content.byteLength - padSize);
    }
}
const genSignature = (timestamp, nonce)=>{
    const sortedArr = [
        _sysconfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"].token */ .Z.token,
        timestamp,
        nonce
    ].sort().join("");
    // sha1加密
    const signature = sha1__WEBPACK_IMPORTED_MODULE_1___default()(sortedArr);
    return signature;
};
class WxCrypt {
    constructor(options){
        this.aesKey = Base64.decode(options.encodingAESKey);
        this.id = options.appId;
        if (this.aesKey.length !== 32) {
            console.error("EncodingAESKey: ", options.encodingAESKey);
            console.error("aesKey: ", this.aesKey);
            //throw new Error('EncodingAESKey should be a 32-length base64 key!');
            this.iv = "123456";
        } else {
            this.iv = this.aesKey.slice(0, 16);
        }
        this.pkcs7Decoder = new Pkcs7Decoder();
        this.pkcs7Encoder = new Pkcs7Encoder();
    }
    encrypt(xmlMsg) {
        const nonce = crypto.randomBytes(8).toString("hex");
        const timestamp = Date.now().toString().substring(0, 10);
        const msg = this.pkcs7Encoder.encode(xmlMsg);
        const msgSizeBuffer = Buffer.alloc(4);
        msgSizeBuffer.writeUInt32BE(msg.length, 0);
        const randomBuffer = crypto.randomBytes(16);
        const tinyIdBuffer = Buffer.from(this.id);
        const buffer = Buffer.concat([
            randomBuffer,
            msgSizeBuffer,
            msg,
            tinyIdBuffer
        ]);
        const cipher = crypto.createCipheriv("aes-256-cbc", Buffer.from(this.aesKey), Buffer.from(this.iv));
        cipher.setAutoPadding(false);
        cipher.update(buffer);
        const ciphered = cipher.final();
        const signature = genSignature(timestamp, nonce);
        const xml = this.buildXml(signature, ciphered.toString("base64"), timestamp, nonce);
        return [
            0,
            xml
        ];
    }
    decrypt(ciphered, signature, timestamp, nonce) {
        const decipher = crypto.createDecipheriv("aes-256-cbc", Buffer.from(this.aesKey), Buffer.from(this.iv));
        decipher.setAutoPadding(false);
        const content = this.pkcs7Decoder.decode(ciphered, "base64");
        decipher.update(content);
        const buffer = decipher.final();
        const length = buffer.readUInt32BE(0);
        const xmlContent = buffer.slice(4, length + 4).toString("utf-8");
        const fromAppId = buffer.slice(length + 4).toString("utf-8");
        if (fromAppId !== this.id) {
            return [
                -1,
                null
            ];
        }
        const msgSignature = genSignature(timestamp, nonce);
        if (msgSignature !== signature) {
            return [
                -2,
                null
            ];
        }
        return [
            0,
            xmlContent
        ];
    }
    buildXml(signature, ciphered, timestamp, nonce) {
        return `
      <xml>
        <Encrypt><![CDATA[${ciphered}]]></Encrypt>
        <MsgSignature><![CDATA[${signature}]]></MsgSignature>
        <TimeStamp>${timestamp}</TimeStamp>
        <Nonce><![CDATA[${nonce}]]></Nonce>
      </xml>
    `;
    }
}
const options = {
    appId: _sysconfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"].appID */ .Z.appID,
    token: _sysconfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"].token */ .Z.token,
    encodingAESKey: _sysconfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"].encodingAESKey */ .Z.encodingAESKey
};
//export const wxCrypt = new WxCrypt(options);
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    genSignature
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 100:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ ReplyCacheModel),
/* harmony export */   "m": () => (/* binding */ SystemLogModel)
/* harmony export */ });
/* harmony import */ var _sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(594);
/* harmony import */ var _models_system_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(283);
/* harmony import */ var _models_reply_cache__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(302);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sequelize__WEBPACK_IMPORTED_MODULE_0__, _models_system_log__WEBPACK_IMPORTED_MODULE_1__, _models_reply_cache__WEBPACK_IMPORTED_MODULE_2__]);
([_sequelize__WEBPACK_IMPORTED_MODULE_0__, _models_system_log__WEBPACK_IMPORTED_MODULE_1__, _models_reply_cache__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// index.ts



const SystemLogModel = (0,_models_system_log__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(_sequelize__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
const ReplyCacheModel = (0,_models_reply_cache__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_sequelize__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
// sequelize.sync({ force: true }).then(() => {
//     console.log('数据库同步成功');
// }).catch((err) => {
//     console.error('数据库同步失败:',err);
// });


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 302:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(210);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__]);
sequelize__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(sequelize) {
    const attributes = {
        id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
            comment: undefined,
            field: "id"
        },
        msgId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "msgId"
        },
        responseId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.STRING(64),
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "responseId"
        },
        input: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.TEXT,
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "input"
        },
        reply: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.TEXT,
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "reply"
        },
        createdAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "createdAt"
        },
        updatedAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "updatedAt"
        },
        expireAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "expireAt"
        }
    };
    const options = {
        tableName: "reply_cache",
        comment: "",
        indexes: []
    };
    const ReplyCacheModel = sequelize.define("reply_cache_model", attributes, options);
    return ReplyCacheModel;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(210);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__]);
sequelize__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(sequelize) {
    const attributes = {
        id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER.UNSIGNED,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
            comment: undefined,
            field: "id"
        },
        level: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.ENUM("error", "warn", "info", "debug"),
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "level"
        },
        message: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.TEXT,
            allowNull: true,
            defaultValue: null,
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "message"
        },
        createdAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "createdAt"
        },
        updatedAt: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.DATE,
            allowNull: false,
            defaultValue: sequelize.literal("CURRENT_TIMESTAMP"),
            primaryKey: false,
            autoIncrement: false,
            comment: undefined,
            field: "updatedAt"
        }
    };
    const options = {
        tableName: "system_log",
        comment: "",
        indexes: []
    };
    const SystemLogModel = sequelize.define("system_log_model", attributes, options);
    return SystemLogModel;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 594:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(210);
/* harmony import */ var _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__]);
sequelize__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// sequelize.ts


// 创建 Sequelize 实例并传递连接参数
const dialect = _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbType */ .Z.dbType;
console.log("dialect:", dialect);
let sequelize = new sequelize__WEBPACK_IMPORTED_MODULE_0__.Sequelize({
    host: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbHost */ .Z.dbHost,
    username: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbUserName */ .Z.dbUserName,
    password: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbPassword */ .Z.dbPassword,
    database: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbDatabase */ .Z.dbDatabase,
    port: _components_sysconfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].dbPort */ .Z.dbPort,
    dialect: dialect
});
// 导出 sequelize 实例
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sequelize);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 557:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_aichat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(401);
/* harmony import */ var _components_validateToken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(957);
/* harmony import */ var _components_template__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(463);
/* harmony import */ var _components_sysconfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71);
/* harmony import */ var xmldom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(435);
/* harmony import */ var xmldom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(xmldom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(648);
/* harmony import */ var _components_accessToken__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(500);
/* harmony import */ var _components_replyCache__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(382);
/* harmony import */ var _components_systemLog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(502);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_validateToken__WEBPACK_IMPORTED_MODULE_1__, axios__WEBPACK_IMPORTED_MODULE_4__, _components_accessToken__WEBPACK_IMPORTED_MODULE_5__, _components_replyCache__WEBPACK_IMPORTED_MODULE_6__, _components_systemLog__WEBPACK_IMPORTED_MODULE_7__]);
([_components_validateToken__WEBPACK_IMPORTED_MODULE_1__, axios__WEBPACK_IMPORTED_MODULE_4__, _components_accessToken__WEBPACK_IMPORTED_MODULE_5__, _components_replyCache__WEBPACK_IMPORTED_MODULE_6__, _components_systemLog__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










async function handleTextMessage(xml, res) {
    if (!xml || !xml.msgid || !xml.fromusername || !xml.tousername || !xml.content) {
        _components_systemLog__WEBPACK_IMPORTED_MODULE_7__/* ["default"].createLog */ .Z.createLog("error", `${JSON.stringify(xml)}`); // 输出无效的XML对象
        return;
    }
    const expireAt = new Date(Date.now() + 20 * 1000);
    const timestamp = Date.now(); // 当前时间戳
    const seed = `${timestamp}_${xml.FromUserName}`; // 种子为时间戳和用户的唯一标识符
    const responseId = crypto__WEBPACK_IMPORTED_MODULE_8__.createHash("md5") // 使用 MD5 散列算法
    .update(seed).digest("hex").substr(0, 4); // 生成 4 位随机数
    // 查询缓存
    console.log("responseId:", responseId);
    const idRegExp = /^([0-9a-zA-Z]{4}|\[[0-9a-zA-Z]{4}\]|【[0-9a-zA-Z]{4}】)$/; // 匹配四位数字、[四位数字]、【四位数字】
    let result = "";
    let cache = null;
    if (idRegExp.test(xml.content)) {
        const regulatedStr = xml.content.replace(/[【】[\]]/g, ""); // 替换方括号和圆括号为空字符串
        console.log("regulatedStr:", regulatedStr);
        const rows = await _components_replyCache__WEBPACK_IMPORTED_MODULE_6__/* ["default"].getCache */ .Z.getCache(xml.msgid, regulatedStr);
        if (Array.isArray(rows)) {
            cache = rows[0];
            rows.forEach((row)=>{
                const { reply  } = row;
                if (reply) {
                    result += `${reply}\n`; // 添加换行符 `\n`
                }
            });
        } else {
            const { reply  } = rows; // 单个对象
            cache = rows;
            if (reply) {
                result = `${reply}`;
            }
        }
        console.log("rows:", rows);
    }
    console.log("result:", result);
    console.log("cache:", cache);
    if (cache) {
        // 如果缓存存在且未过期，直接返回响应
        let message;
        if (result) {
            message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: result
            };
        } else {
            message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: "正在处理，请稍后..."
            };
        }
        res.send((0,_components_template__WEBPACK_IMPORTED_MODULE_9__/* .textMessage */ .MK)(message));
    } else {
        // 如果缓存不存在或已过期，则查询 AI Chat Bot 并保存缓存和请求
        const newRecord = await _components_replyCache__WEBPACK_IMPORTED_MODULE_6__/* ["default"].saveCache */ .Z.saveCache(xml.msgid, responseId, xml.content, null, expireAt); // 将响应 ID 插入数据库
        if (_components_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].isAuthenticated */ .Z.isAuthenticated === true) {
            res.send(`正在处理【${responseId}】，请稍后得到结果会反馈给您，或者稍后发送【${responseId}】获取结果`);
        } else {
            const message = {
                FromUserName: xml.fromusername,
                ToUserName: xml.tousername,
                reply: `正在处理，请稍后发送【${responseId}】获取结果`
            };
            res.send((0,_components_template__WEBPACK_IMPORTED_MODULE_9__/* .textMessage */ .MK)(message));
        }
        const reply = await _components_aichat__WEBPACK_IMPORTED_MODULE_0__/* ["default"].getReply */ .Z.getReply(xml.content);
        await newRecord.update({
            reply: reply
        }); // 将响应数据更新到数据库
        if (_components_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].isAuthenticated */ .Z.isAuthenticated === true) {
            try {
                const replyXmlMessage = (0,_components_template__WEBPACK_IMPORTED_MODULE_9__/* .textMessage */ .MK)({
                    FromUserName: xml.fromusername,
                    ToUserName: xml.tousername,
                    reply: reply
                });
                const AccessToken = await (0,_components_accessToken__WEBPACK_IMPORTED_MODULE_5__/* .getAccessToken */ .h)();
                const replyRes = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].post(`https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=${AccessToken}`, replyXmlMessage, {
                    headers: {
                        "Content-Type": "text/xml;charset=utf-8",
                        "Content-Length": Buffer.byteLength(replyXmlMessage, "utf8")
                    }
                });
                _components_systemLog__WEBPACK_IMPORTED_MODULE_7__/* ["default"].createLog */ .Z.createLog("info", `${JSON.stringify(replyRes)}`);
            } catch (error) {
                _components_systemLog__WEBPACK_IMPORTED_MODULE_7__/* ["default"].createLog */ .Z.createLog("error", `${JSON.stringify(error)}`);
            }
        }
    }
}
async function handleSubscribeEvent(xml, res) {
    const message = {
        FromUserName: xml.fromusername,
        ToUserName: xml.tousername,
        reply: _components_sysconfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].subscribeReply */ .Z.subscribeReply
    };
    res.send((0,_components_template__WEBPACK_IMPORTED_MODULE_9__/* .textMessage */ .MK)(message).toString());
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    const { method  } = req;
    let result;
    try {
        result = await (0,_components_validateToken__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(req);
        console.info(result);
    } catch (error) {
        console.error(error.message);
    }
    switch(method){
        case "GET":
            res.send(result);
            break;
        case "POST":
            console.log(typeof req.body); // 应该输出 "object"
            console.log(req.body);
            const parser = new xmldom__WEBPACK_IMPORTED_MODULE_3__.DOMParser();
            const xmlDoc = parser.parseFromString(req.body, "text/xml");
            let xml = {
                tousername: xmlDoc.getElementsByTagName("ToUserName")[0]?.textContent || "",
                fromusername: xmlDoc.getElementsByTagName("FromUserName")[0]?.textContent || "",
                createtime: parseInt(xmlDoc.getElementsByTagName("CreateTime")[0]?.textContent || "0", 10),
                msgtype: xmlDoc.getElementsByTagName("MsgType")[0]?.textContent || "",
                content: xmlDoc.getElementsByTagName("Content")[0]?.textContent || "",
                msgid: xmlDoc.getElementsByTagName("MsgId")[0]?.textContent || "",
                event: xmlDoc.getElementsByTagName("Event")[0]?.textContent || "",
                eventkey: xmlDoc.getElementsByTagName("EventKey")[0]?.textContent || "",
                encrypt: xmlDoc.getElementsByTagName("Encrypt")[0]?.textContent || ""
            };
            if (xml.encrypt) {
                console.log(typeof xml); // 应该输出 "object"
                console.log(xml); // 应该输出您提供的 XML 数据对象
            }
            const msgType = xml.msgtype;
            switch(msgType){
                case "text":
                    await handleTextMessage(xml, res);
                    break;
                case "event":
                    switch(xml.event){
                        case "subscribe":
                            await handleSubscribeEvent(xml, res);
                            break;
                        case "unsubscribe":
                        default:
                            res.send("");
                            break;
                    }
                    break;
                default:
                    res.send("");
                    break;
            }
            break;
        default:
            res.setHeader("Allow", [
                "GET",
                "POST"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
            break;
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(557));
module.exports = __webpack_exports__;

})();